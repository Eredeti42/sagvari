t = list(map(lambda x: list(map(int, x.split("-"))),open("input.txt").read().split("\n")))
from functools import reduce

print("2.feladat")
print(f'Az 1. sorban szereplő számok átlaga: {sum(t[0])/len(t[0])}')

print("3.feladat")

t3 = list(map(lambda x: x**2,sorted(t[1], reverse=True)[-12:]))
print(f'A 2. sorban szereplő 8 legnagyobb szám négyzetének összege: {sum(t3)}')

print("4. feladat")
t4 = reduce(lambda x, y: x * y, filter(lambda x: x % 3==0, t[2]))
print(f'A 3. sorban szereplő 3-mal nem osztható számok szorzatának nagyságrendje: 10^{len(str(t4))}')

print("5.feladat")
megoldas5 = reduce(lambda x, y: x+y,  filter(lambda x: x<21,t[3]))
print(f"A 4. sorban szereplő 21-nél kisebb számok összege: {megoldas5}")

print("6.feladat")

megoldas6 = reduce(lambda x, y: x if x > y else y, filter(lambda x: x % 2 == 0, t[4]))
print(f"Az 5. sorban szereplő páros számok maximuma: {megoldas6}")

print("7.feladat")
megoldas7 = min(sorted(sum(t, []), reverse = True)[:17])
print(f"Az inputban szereplő összes szám közül a 17 legnagyobb szám minimuma: {megoldas7}")




